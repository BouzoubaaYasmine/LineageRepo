import json
import requests

# Define the API URL
api_url = "http://localhost:3000/api/v1/lineage?nodeId=dataset:postgres://localhost:5435:lineagetutorial.final_transformed_data"
response = requests.get(api_url)

if response.status_code == 200:
    api_data = response.json()

    transformed_data = {
        "graph": []
    }

    for item in api_data.get("graph", []):
        if item['type'] == 'DATASET':
            dataset_info = {
                "id": item['id'],
                "type": "DATASET",
                "data": {
                    "name": item['data']['name'],
                    "fields": [{"name": field['name'], "type": field['type']} for field in item['data'].get('fields', [])]
                },
                "inEdges": item['inEdges'],
                "outEdges": item['outEdges']
            }
            transformed_data['graph'].append(dataset_info)
        elif item['type'] == 'JOB':
            job_info = {
                "id": item['id'],
                "type": "JOB",
                "data": {
                    "name": item['data']['name']
                },
                "inEdges": item['inEdges'],
                "outEdges": item['outEdges']
            }
            transformed_data['graph'].append(job_info)

    output_file_path = 'graphData.json'
    with open(output_file_path, 'w') as json_file:
        json.dump(transformed_data, json_file, indent=4)

    print(f"Data has been written to {output_file_path}")

else:
    print(f"Failed to retrieve data: {response.status_code} - {response.text}")
