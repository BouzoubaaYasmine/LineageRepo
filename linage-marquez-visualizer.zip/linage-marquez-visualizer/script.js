// Fetch the graph data from a JSON file
fetch('graphData.json')
    .then(response => response.json())
    .then(graphData => {
        // Create a directed graph
        const g = new dagreD3.graphlib.Graph().setGraph({
            rankdir: 'LR', // Set the graph direction to left-to-right
            ranksep: 100   // Increase separation between ranks
        });

        // Add nodes to the graph
        graphData.graph.forEach(node => {
            const label = `
                <div class="node-content">
                    <div class="node-header">
                        <div class="icon"><i class="fas ${node.type === 'DATASET' ? 'fa-database' : 'fa-cog'}"></i></div>
                        <div class="title">${node.data.name}</div>
                    </div>
                    <hr>
                    ${node.data.fields ?
                        `<div class="properties">
                            ${node.data.fields.map(f => `
                                <div class="field">
                                    <span class="field-icon">${getFieldIcon(f.type)}</span>
                                    <span>${f.name}</span>
                                </div>
                            `).join('')}
                        </div>`
                        : ''}
                </div>`;
            g.setNode(node.id, {
                label: label,
                class: node.type.toLowerCase(),
                labelType: 'html',
                padding: 0,
                shape: 'rect',
                data: node.data
            });
        });

        // Add edges to the graph
        graphData.graph.forEach(node => {
            node.outEdges.forEach(edge => {
                g.setEdge(edge.origin, edge.destination, {});
            });
        });

        // Create the renderer
        const render = new dagreD3.render();

        // Set up an SVG group so that we can translate the final graph.
        const svg = d3.select("#graph").append("svg")
            .attr("width", "100%")
            .attr("height", "100%")
            .attr("preserveAspectRatio", "xMinYMin meet");
        const svgGroup = svg.append("g");

        // Run the renderer. This is what draws the final graph.
        render(svgGroup, g);

        // Center the graph and scale it to fit the screen width
        const xScale = window.innerWidth / (g.graph().width + 80);
        const yScale = window.innerHeight / (g.graph().height + 40);
        const scale = Math.min(xScale, yScale);
        const xCenterOffset = (window.innerWidth - g.graph().width * scale) / 2;
        const yCenterOffset = (window.innerHeight - g.graph().height * scale) / 2;

        svgGroup.attr("transform", `translate(${xCenterOffset}, ${yCenterOffset}) scale(${scale})`);

                const zoom = d3.zoom()
                    .scaleExtent([0.1, 8])
                    .on("zoom", function() {
                        svgGroup.attr("transform", d3.event.transform);
                    });

                svg.call(zoom).call(zoom.transform, d3.zoomIdentity.translate(xCenterOffset, yCenterOffset).scale(scale));

                // Add window resize event listener
                window.addEventListener('resize', function() {
                    const xScale = window.innerWidth / (g.graph().width + 80);
                    const yScale = window.innerHeight / (g.graph().height + 40);
                    const scale = Math.min(xScale, yScale);
                    const xCenterOffset = (window.innerWidth - g.graph().width * scale) / 2;
                    const yCenterOffset = (window.innerHeight - g.graph().height * scale) / 2;
                    svg.call(zoom.transform, d3.zoomIdentity.translate(xCenterOffset, yCenterOffset).scale(scale));
                });

                // Animation
                // Hide all nodes and edges initially
                svg.selectAll(".node, .edgePath").style("opacity", 0);

                // Animate nodes
                svg.selectAll(".node")
                    .transition()
                    .duration(1000)
                    .delay((d, i) => i * 200)
                    .style("opacity", 1)
                    .on("end", function(d) {
                        // Add click event after node animation is complete
                        d3.select(this).on("click", function() {
                            const nodeData = g.node(d).data;
                            if (nodeData && nodeData.fields) {
                                showRightMenu(nodeData);
                            }
                        });
                    });

                // Animate edges and add flowing bubbles
                svg.selectAll(".edgePath")
                    .transition()
                    .duration(1000)
                    .delay((d, i) => i * 200 + svg.selectAll(".node").size() * 200)
                    .style("opacity", 1)
                    .on("end", function() {
                        const edge = d3.select(this);
                        const path = edge.select("path").node();
                        const pathLength = path.getTotalLength();

                        // Create multiple bubbles for each edge
                        for (let i = 0; i < 3; i++) {
                            edge.append("circle")
                                .attr("class", "flow-circle")
                                .attr("r", 4) // Slightly larger bubbles
                                .attr("opacity", 0.8) // More opaque
                                .call(translateAlongPath, path, pathLength, i * 33);
                        }
                    });

                function translateAlongPath(circle, path, pathLength, delay) {
                    circle.transition()
                        .duration(1500) // Faster animation (1.5 seconds instead of 3)
                        .delay(delay)
                        .attrTween("transform", translateAlong(path))
                        .on("end", function() {
                            d3.select(this).call(translateAlongPath, path, pathLength, 0);
                        });
                }

                function translateAlong(path) {
                    const l = path.getTotalLength();
                    return function(d, i, a) {
                        return function(t) {
                            const p = path.getPointAtLength(t * l);
                            return "translate(" + p.x + "," + p.y + ")";
                        };
                    };
                }


                function getFieldIcon(type) {
                    switch(type) {
                        case 'integer':
                            return '🔢';
                        case 'string':
                            return '🆎';
                        case 'date':
                            return '🕒';
                        default:
                            return '❓';
                    }
                }
            })
            .catch(error => console.error('Error fetching the graph data:', error));

