* https://cytoscape.org/
* d3 
* Dagre 

Exampls : 
* https://github.com/kiali/kiali/tree/master

